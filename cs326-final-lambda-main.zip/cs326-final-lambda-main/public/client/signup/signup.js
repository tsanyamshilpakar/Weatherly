document.getElementById('loginBTN').addEventListener('click', () => {
    window.location.pathname = '/login';
})

document.getElementById('signupBTN').addEventListener('click', () => {
    let user = new Array(2);
    user[0] = document.getElementById('SignUpEmail').value;
    user[1] = document.getElementById('SignUpPassword').value;
    let checker = true;

    fetch("/getusers", { method: 'GET' })
        .then(response => {
            if (response.ok) {
                response.json().then(json => {
                    //console.log(json);
                    if (json.length > 0) {
                        for (let i = 0; i < json.length; ++i) {
                            if (json[i].username === user[0]) {
                                checker = false;
                                window.location.pathname = '/signup'
                                //return checker;
                                break;
                            }
                        }
                    }
                });
            }
        })
        .then(temp => {
            if (checker) {
                fetch("/postuser", {
                    // Adding method type 
                    method: "POST",
                    // Adding body or contents to send 
                    body: JSON.stringify({
                        data: user
                    }),
                    // Adding headers to the request 
                    headers: {
                        "Content-type": "application/json"
                    }
                })
                    .then(response => response.text())
                    .then(_data => {
                        console.log('Success', _data);
                        window.location.pathname = '/dashboard'
                    })
            }
        });
}) 