//const fetch = require("node-fetch");

let apiKey = '9e1a14d4043264a845e04cc01c388c35';//process.env.WEATHERAPI;
//let city = document.getElementById("location").value;
let zipCode = '';
let latitude;
let longitude;
document.getElementById('weather-button').addEventListener('click', () => {
  latitude = parseInt(document.getElementById('latitude').value);
  longitude = parseInt(document.getElementById('longitude').value);

  let url = `https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&units=imperial&exclude=hourly,minutely,alerts,current&appid=${apiKey}`
  fetch(url)
    .then(function (resp) { return resp.json() }) // Convert data to json
    .then(function (data) {
      let temp1 = data.daily[0].temp.day;
      let weather1 = data.daily[0].weather[0].main;
      document.getElementById('day_1').innerHTML = temp1 + '° F<br>' + weather1;
      weatherImg(weather1, 1);

      fetch("/postweather", {
        // Adding method type 
        method: "POST",
        // Adding body or contents to send 
        body: JSON.stringify({
          data: weather1
        }),
        // Adding headers to the request 
        headers: {
          "Content-type": "application/json"
        }
      })
      .then(response => response.text())
      .then(_data => {
          console.log('POST weather: Success');
          window.location.pathname = '/dashboard'
      })
      let temp2 = data.daily[1].temp.day;
      let weather2 = data.daily[1].weather[0].main;
      document.getElementById('day_2').innerHTML = temp2 + '° F<br>' + weather2;
      weatherImg(weather2, 2);

      let temp3 = data.daily[2].temp.day;
      let weather3 = data.daily[2].weather[0].main;
      document.getElementById('day_3').innerHTML = temp3 + '° F<br>' + weather3;
      weatherImg(weather3, 3);

      let temp4 = data.daily[3].temp.day;
      let weather4 = data.daily[3].weather[0].main;
      document.getElementById('day_4').innerHTML = temp4 + '° F<br>' + weather4;
      weatherImg(weather4, 4);

      let temp5 = data.daily[4].temp.day;
      let weather5 = data.daily[4].weather[0].main;
      document.getElementById('day_5').innerHTML = temp5 + '° F<br>' + weather5;
      weatherImg(weather5, 5);

      fetch("/getspotify", { method: 'GET' })
      .then(response => {
        if (response.ok) {
          response.json().then(json => {
            document.getElementById('spotTable').innerHTML = '';
            document.getElementById('spotTable').innerHTML = '<table class="table table-hover table-dark"><thead><tr><th scope="col">#</th><th scope="col">Track_ID</th><th scope="col">Song Name</th></tr></thead><tbody id="test123"></tbody></table>';
            let li ='';
            for(let i = 0; i<json.length; ++i){
              li += `<tr> 
              <td>${json[i].index} </td> 
              <td>${json[i].id}</td>
              <td>${json[i].album_name}</td>              
          </tr>`;
            }
            document.getElementById('test123').innerHTML = li;
          });
        }
      });

  if (data.cod === '404') {
    document.getElementById("location").value = "INVALID CITY";
  }

});
});



document.getElementById("detect").addEventListener('click', () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    document.getElementById("location").value = "Geolocation is not supported by this browser.";
  }

  function showPosition(position) {
    console.log('lat: ' + position.coords.latitude +
      "Long:" + position.coords.longitude);
    latitude = position.coords.latitude;
    document.getElementById('latitude').value = position.coords.latitude;
    longitude = position.coords.longitude;
    document.getElementById('longitude').value = position.coords.longitude;
  }

});


function weatherImg(weather, index) {
  if (weather === 'Thunderstorm') {
    document.getElementById(`weather_${index}`).src = '/client/dashboard/stormy.jpg';
  } else if (weather === 'Drizzle' || weather === 'Rain') {
    document.getElementById(`weather_${index}`).src = '/client/dashboard/rainy.jpg';
  } else if (weather === 'Snow') {
    document.getElementById(`weather_${index}`).src = '/client/dashboard/snowy.jpg';
  } else if (weather === 'clear') {
    document.getElementById(`weather_${index}`).src = '/client/dashboard/sunny.jpg';
  } else {
    document.getElementById(`weather_${index}`).src = '/client/dashboard/cloudy.jpg';
  }

}

//Thunderstorm == stormy.jpg, (Drizzle || Rain) == rainy.jpg, Snow == snowy.jpg, Clear == sunny.jpg, everything else = cloudy.jpg
