document.getElementById('signupBTN').addEventListener('click', () => {
    window.location.pathname ='/signup';
}) 


document.getElementById('loginBTN').addEventListener('click', () => {
    let user = new Array(2);
    user[0] = document.getElementById('InputEmail').value;
    user[1] = document.getElementById('InputPassword').value;

    fetch("/getuser_pswd", { method: 'GET' })
        .then(response => {
            if (response.ok) {
                response.json().then(json => {
                    if (json.length > 0) {
                        for (let i = 0; i < json.length; ++i) {
                            console.log(i);
                            if (json[i].username === user[0] && json[i].password === user[1]) {
                                window.location.pathname = '/dashboard'
                                break;
                            } else if (i === json.length-1){
                                window.location.pathname = '/login'
                            }
                        }
                    }
                });
            }
        });

}) 