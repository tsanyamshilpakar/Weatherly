document.getElementById('signupBTN').addEventListener('click', () => {
    window.location.pathname ='/signup';
}) 