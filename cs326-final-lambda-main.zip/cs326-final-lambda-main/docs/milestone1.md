# TEAM NAME

* Lambda

# WEB APPLICATION NAME

* Weatherly

# Team Overview

  * Kalyan Maddineni:   [@kcmadd](https://github.com/kcmadd)
  * Nikhil Rajkumar:      [@nikhil-rajkumar](https://github.com/nikhil-rajkumar)
  * Sanyam Shilpakar:  [@sanyamshilpakar](https://github.com/sanyamshilpakar) 

# Innovative Idea/Data Interactions

* This project is centered around using the Spotify API and a weather API such as Dark Sky API or OpenWeatherMap API to generate a playlist that correlates to the mood of the current weather of the area. For instance, if it is raining in the area, the generated playlist will be a bit more slow and mellow. As this project utilizes the Spotify API, it does relate to Spotify’s web application.

# Wireframes
![frontpage](https://github.com/kcmadd/cs326-final-lambda/blob/main/HTML%20and%20CSS/Wireframes/frontpage_wireframe.JPG)
![signup](https://github.com/kcmadd/cs326-final-lambda/blob/main/HTML%20and%20CSS/Wireframes/SignupPage_wireframe.JPG)
![login](https://github.com/kcmadd/cs326-final-lambda/blob/main/HTML%20and%20CSS/Wireframes/LoginPage_wireframe.JPG)
![dashboard](https://github.com/kcmadd/cs326-final-lambda/blob/main/HTML%20and%20CSS/Wireframes/dashboard_wireframe.jpg)

NOTE: these wireframe were designed and created on an iPad using a combination of sketches and screenshots

# User Interface
![frontpage](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/frontpage.JPG)
Front Page: created by Kalyan

![signup](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/signup.JPG)
Sign Up page: created by Sanyam

![login](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/login.JPG)
Login Page: created by Nikhil

![dashboard](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/Dashboard.JPG)
Dashboard: base created by Kalyan, filters created by Nikhil

# Contributions
* Kalyan created the Dashboard and Front Page
* Nikhil created the Login Page and Filters for Dashboard
* Sanyam designed the UI/Wireframes with input from group members and created the Sign Up page
