# 1. Database
We used Postgresql for our DBMS 
Our project utilizes four tables: **SPOTIFYTRACKS**, **TRACKNAMES**, **ARTISTNAMES**, and
SPOTIFYTRACKS stores metrics about the songs like valence and energy level  
  #### **SPOTIFYTRACKS:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Danceablity | DECIMAL   | Metric for how suitable song is for dancing  |
| Energy      | DECIMAL   | Metric for intensity and activity            |
| Key         | DECIMAL   | Estimated overall key for course             |
| Loudness    | DECIMAL   | Metric for loudness of course                |
| Mode        | DECIMAL   | Metric for modality of track                 |
| Speechiness | DECIMAL   | Metric for presence of spoken works in track |
| Liveness    | DECIMAL   | Metric for 'audience' in song                |
| Valence     | DECIMAL   | Metric for musical positivity                |
| Tempo       | DECIMAL   | Metric for tempo of track                    |
| ID          | TEXT      | Unique ID for each song                      |
| Index       | SERIAL    | Index for each row                           |  

#### **ARTISTNAMES:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Artist_Name | TEXT      | Artist Name of each Track                    |
| Index       | SERIAL    | Index for each row                           |

#### **TRACKNAMES:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Track_Name  | TEXT      | Track Name of each Track                     |
| Index       | SERIAL    | Index for each row                           |
 
 #### **USERINFO:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| uname       | TEXT      | username                                     |
| salt        | TEXT      | salt (minicrypt)                             |
| hash        | TEXT      | hash (minicrypt)                             |
  
 
# 2. Division of Labour
* Kalyan worked on incorporating spotify-web-api data with the database and linked Front-End to Back-End
* Sanyam worked on the spotify-web-api helper functions, song metric bounds for each type of weather, and minicrypt implementation
* Nikhil worked on spotify-web-api helper functions and authorization and server-minicrypt implementation

# 3. Heroku
* https://cs-326-lambda.herokuapp.com
