# 1. Title
* Weatherly
# 2. Subtitle
* Same as Title
# 3. Semester
* Fall 2020
# 4. Overview
This application is a spotify and weather based playlist generator that generates a playlist based off of the current weather of the users location.
It's innovative because it allows users to generate several different palylists based on the current mood that is derived from the weather
# 5. Team Members
 * Kalyan Maddineni:   [@kcmadd](https://github.com/kcmadd)
  * Nikhil Rajkumar:      [@nikhil-rajkumar](https://github.com/nikhil-rajkumar)
  * Sanyam Shilpakar:  [@sanyamshilpakar](https://github.com/sanyamshilpakar) 
# 6a. User Interface (Table)
There are four different 'pages' in the UI:
* The first is the frontpage
* the second is the signup page
* the third is the login page
* the forth is the dashboard where the playlist generation occurs
# 6b. User Interface (Screenshots)
Frontpage Screenshot:
![frontpage](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/Weatherly_final.png)
Signup Page Screenshot:
![signup](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/Signup_final.png)
Login Page Screenshot:
![login](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/Login_final.png)
Dashboard (on initial load):
![dashboard_onload](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/dashboard_onload_final.png)
Dashboard (after playlist generation):
![dashboard_playlist](https://github.com/kcmadd/cs326-final-lambda/blob/main/Screenshots/dashboard_playlist_final.png)

Purpose of Front page:
* initial page that users see when going to website
Purpose of Signup:
* page for users to signup on
Purpose of Login:
* page for users to login
Purpose of Dashboard:
* page Users can see the playlist generated based on weather


# 7. APIs
There are two APIs being used:
* spotify-web-api -> Is used to pull all songs from the global top 200 playlist
* OpenWeather apu -> Is used to pull weather data for the next 5 days 
# 8. Database
  #### **SPOTIFYTRACKS:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Danceablity | DECIMAL   | Metric for how suitable song is for dancing  |
| Energy      | DECIMAL   | Metric for intensity and activity            |
| Key         | DECIMAL   | Estimated overall key for course             |
| Loudness    | DECIMAL   | Metric for loudness of course                |
| Mode        | DECIMAL   | Metric for modality of track                 |
| Speechiness | DECIMAL   | Metric for presence of spoken works in track |
| Liveness    | DECIMAL   | Metric for 'audience' in song                |
| Valence     | DECIMAL   | Metric for musical positivity                |
| Tempo       | DECIMAL   | Metric for tempo of track                    |
| ID          | TEXT      | Unique ID for each song                      |
| Index       | SERIAL    | Index for each row                           |  

#### **ARTISTNAMES:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Artist_Name | TEXT      | Artist Name of each Track                    |
| Index       | SERIAL    | Index for each row                           |

#### **TRACKNAMES:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| Track_Name  | TEXT      | Track Name of each Track                     |
| Index       | SERIAL    | Index for each row                           |
 
 #### **USERINFO:**
| Column      | Data_type | Description                                  |
|-------------|-----------|----------------------------------------------|
| uname       | TEXT      | username                                     |
| salt        | TEXT      | salt (minicrypt)                             |
| hash        | TEXT      | hash (minicrypt)                             |
# 9. URL Routes
| URL Routes    | Description                                   |
|---------------|-----------------------------------------------|
| /             | Frontpage                                     |
| /dashboard    | URL endpoint for Dashboard page               |
| /login        | URL endpoint for login page                   |
| /signup       | URL endpoint for signup page                  |
| /postweather  | Post Weather Data to Database                 |
| /postspotify  | Posts spotify-web-api data to Database        |
| /getspotify   | Gets Filtered Spotify Data from Database      |
| /getusers     | Gets and Checks for User on Database          |
| /getuser_pswd | Gets and Checks for User Password on Database |
| /postuser     | Posts Username and Password to Database       |
# 10. Authentication
* Login and Signup pages relate to user authentication
* Username and Password are stored on the database and are requested when need be on the login page
# 11. Division of Labor
* Kalyan designed the Dashboard page, integrated the frontend and backend together, and created the postgres querys for storing and querying data onto the database
* Sanyam designed the frontpage, created the promise chains for pulling the spotify and weather data from the APIs, and worked on user authentication
* Nikhil created the server, designed the login and signup page, worked with user authentication, and created the promise chains for pulling the spotify data
# 12. Conclusion
The biggest thing that this team learned was:
* how to work together as a team over zoom
* how to make API request and store the data sent
* how to integrate databases into projects

As a group, we found several things hard such as:
* Working together over zoom was difficult, everyone was in different timezones
* Working with spotify data was also pretty hard, we had to use a wrapper which was still in active development. It also did not have support for ES6

We felt like it would have been helpful
* to know how to use the APIs beforehand
* know how to use express befofehand
* know how to use all of the APIs beforehand


