Once repo is cloned onto a local computer, project should be able to be loaded via an npm start command where the server is listening on port 8000
