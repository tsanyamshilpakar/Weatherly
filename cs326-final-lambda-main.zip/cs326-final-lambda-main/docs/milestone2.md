# 1. API description
* OneCall API in weather.js does a GET request provide weather forecast data for the next 5 days. This data will be visualized on the dashboard in weach respective card
* The Spotify Web API will do a majority of the CRUD operations. It will it pull the top N songs of the user and store it on the database, it will update the songs stored of there is custom filters set on the dashboard, it will read the data stored to create an album
* the server has endpoints that fetches and loads the CSS, HTML, and JS for each endpoint
# 2. Screenshots
* We cannot show screenshots of CRUD operations performed on our website as the entire backend has to be finished before it can be visualized.
Steps required to visualize CRUD operations:
1. Pull Weather Data for USER via OneCall API
2. Pull users TOP N songs
3. Store songs on database
4. sort the songs into a "buckets"
5. take the songs in the bucket corresponding to the weather and generate a playlist using the spotify web API
6. visualize the playlist

We would essentially have to create several dummy endpoint and do a majority of the backend (which will be done in the next milestone) before we could visualize the CRUD operations. 

# 3. URL of for Heroku Application
* https://cs-326-lambda.herokuapp.com/
# 4. Division of Labor
* Kalyan created weather.js to pull data from weather forecast data from OpenWeatherMap using their OneCall API and added functionality for buttons on the dashboad
* Sanyam created temporary endpoints for the spotify data (this will eventually be replaced with the spotify web api)
* Nikhil created the server and server enpoints for the actual website such that it would load a certain set of HTML, CSS, and JS files per enpoint
