**1. Team Name**
  * Lambda


**2. Application Name**
  *  Weather Playlist Generator


**3. Team Overview**
  * Kalyan Maddineni:   [@kcmadd](https://github.com/kcmadd)
  * Nikhil Rajkumar:      [@nikhil-rajkumar](https://github.com/nikhil-rajkumar)
  * Sanyam Shilpakar:  [@sanyamshilpakar](https://github.com/sanyamshilpakar) 


**4. Innovative Idea**
* This project is centered around using the Spotify API and a weather API such as Dark Sky API or OpenWeatherMap API to generate a playlist that correlates to the mood of the current weather of the area. For instance, if it is raining in the area, the generated playlist will be a bit more slow and mellow. As this project utilizes the Spotify API, it does relate to Spotify’s web application


**5. Important components**
* As mentioned above, this project is utilizing the Spotify API. This API at a minimum will provide genre and artist names. On a finer level, the Spotify API provides “audio features” which includes ratings on acousticness, danceability, energy, liveliness, valance, etc. All of these ratings are going to serve as a basis for our playlist generation, More information about these ratings can be found [here](https://developer.spotify.com/documentation/web-api/reference/tracks/get-audio-features/)


* Additionally, We’re going to be using either DarkSky API or OpenWeatherMap API to get the weather of the current location of the user. This API only needs to provide data on the weather for the next 12 to 24 hours.


* Lastly, we’re going to be using Bootstrap 3 or 4 for the front-end of our project with the backend done in NodeJS. As per the requirements, the application will be deployed using Heroku
