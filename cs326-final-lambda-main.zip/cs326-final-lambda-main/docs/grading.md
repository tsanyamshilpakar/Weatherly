# Grading 
| Name                             | Description                                                                                              | Weight |
|----------------------------------|----------------------------------------------------------------------------------------------------------|--------|
| UI/UX                            | Is the UI/UX User Friendly?                                                                              | 25%    |
| Functionality                    | How easy is it to use the web app? Does everything work as intended?                                     | 25%    |
| File Structure                   | Is the code for the project organized? (Has separate files for there respective use cases, proper names) | 20%    |
| Code Cleanliness                 | Is the code easy to read and follows proper rule? (eg. 'var' isn't used, == isn't used, etc)             | 10%    |
| Security and User Authentication | Is the user authentication functional for all edge-cases?                                                | 7.5%   |
| Minicrypt                        | Is user data stored securely?                                                                            | 7.5%   |
| Documentation                    | Is the documentation(milestone1.md through final.md) easy to follow/read?                                | 5%     |
