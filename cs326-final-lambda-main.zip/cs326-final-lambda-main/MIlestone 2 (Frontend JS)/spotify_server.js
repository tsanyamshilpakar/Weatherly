import {createServer} from 'http';
import {parse} from 'url';
import {writeFile, readFileSync, existsSync} from 'fs';let spotify_db;
if (existsSync("spotify_db.json")) {
    spotify_db = JSON.parse(readFileSync("spotify_db.json"));
} else {
    spotify_db = {
        user_id: [],
        playlist: []
    };
}createServer(async (req, res) => {
    const parsed = parse(req.url, true);    if (parsed.pathname === '/user_id') {
        let body = '';
        req.on('data', data => body += data);
        req.on('end', () => {
            const data = JSON.parse(body);
            spotify_db.user_id.push({
                client_id: data.client_id, //spotify client id
                client_secret: data.client_secret // spotify secret id
            });            writeFile("spotify_db.json", JSON.stringify(spotify_db), err => {
                if (err) {
                    console.err(err);
                } else res.end();
            });
        });
    } else if (parsed.pathname === '/playlist') {
        response.writeHead(200, { 'content-type': 'text/json' });
        response.write("hello");
        let body = '';
        req.on('data', data => body += data);
        req.on('end', () => {
            const data = JSON.parse(body);
            spotify_db.playlist.push({
                song_id: {
                    song_name: data.song_id.song_name,//string
                    artist_name: data.song_id.artist_name, //string 
                    album_name: data.song_id.album_name, //string
                    rating: {  
                        dancablity: data.song_id.rating.dancablity, // 0.0 means no dancablity and 1.0 means dancablity
                        liveliness: data.song_id.rating.liveliness, // above 0.8 means likelihood that the track is live
                        valence: data.song_id.rating.valence, // from range 0.0 to 1.0, high valence sound means more positive and low valence means negative
                        tempo: data.song_id.rating.tempo
                    },
                    song_length: data.song_id.song_length //number
                }
            });            writeFile("spotify_db.json", JSON.stringify(spotify_db), err => {
                if (err) {
                    console.err(err);
                } else res.end();
            });
        });
    } else {
        res.writeHead(404);
        res.end();
    }
}).listen(8080);
