//const fetch = require("node-fetch");


document.getElementById('weather-button').addEventListener('click', () => {
let apiKey = 'Super-Secret-API-Key';
let city = document.getElementById("location").value;
let zipCode = '';

let url = `https://api.openweathermap.org/data/2.5/onecall?lat=42&lon=-72&exclude=hourly,minutely,alerts,current&appid=${apiKey}`
fetch(url)
    .then(function (resp) { return resp.json() }) // Convert data to json
    .then(function (data) {
        console.log(data);
        if(data.cod === '404'){
          document.getElementById("location").value = "INVALID CITY";
        }
      
    });
});
